/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unocard;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author humer
 */
public class UnocardTest {
    
    public UnocardTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getFace method, of class Unocard.
     */
    @Test
    public void testGetFace() {
        System.out.println("getFace");
        Unocard instance = new Unocard();
        String expResult = "";
        String result = instance.getFace();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of canPlace method, of class Unocard.
     */
    @Test
    public void testCanPlace() {
        System.out.println("canPlace");
        Unocard o = null;
        String c = "";
        Unocard instance = new Unocard();
        boolean expResult = false;
        boolean result = instance.canPlace(o, c);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
